#!/bin/bash

# Turn on bluetooth by default
chrootable_systemctl_enable bluetooth.service
