# Update localdb so that locate will find everything installed
sudo updatedb
