#!/bin/bash

# Allow the user to change the branding for fastfetch and screensaver
mkdir -p ~/.config/omarchy/branding
cp ~/.local/share/omarchy/icon.txt ~/.config/omarchy/branding/about.txt
cp ~/.local/share/omarchy/logo.txt ~/.config/omarchy/branding/screensaver.txt
