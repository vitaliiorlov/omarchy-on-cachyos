echo "Add Samba network drive support to the file manager"

omarchy-pkg-add gvfs-smb
