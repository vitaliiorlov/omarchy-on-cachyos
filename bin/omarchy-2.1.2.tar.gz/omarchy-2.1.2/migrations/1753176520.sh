echo "Install wf-recorder for screen recording for nvidia"

omarchy-pkg-add wf-recorder
