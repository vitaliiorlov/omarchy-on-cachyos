echo "Install Plymouth splash screen"

omarchy-pkg-add uwsm plymouth
source "$OMARCHY_PATH/install/login/plymouth.sh"
