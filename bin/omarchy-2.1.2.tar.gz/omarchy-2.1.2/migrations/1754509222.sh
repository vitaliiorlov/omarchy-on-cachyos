echo "Add xmlstarlet needed for updating fonts via Omarchy menu"

omarchy-pkg-add xmlstarlet
