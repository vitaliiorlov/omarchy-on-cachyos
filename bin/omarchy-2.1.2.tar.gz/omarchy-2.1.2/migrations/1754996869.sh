echo "Increase sudo attempts limit to 10"

source $OMARCHY_PATH/install/config/increase-sudo-tries.sh
