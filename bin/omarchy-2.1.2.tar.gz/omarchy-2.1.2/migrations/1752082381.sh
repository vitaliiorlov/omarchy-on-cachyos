echo "Adding gnome-keyring to make 1password work with 2FA codes"

omarchy-pkg-add gnome-keyring
