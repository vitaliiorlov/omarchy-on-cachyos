echo "Remove old About, Activity, Audio Settings apps that are in Omarchy Menu or hotkey"

rm -f ~/.local/share/applications/About.desktop
rm -f ~/.local/share/applications/Activity.desktop
rm -f ~/.local/share/applications/wiremix.desktop
