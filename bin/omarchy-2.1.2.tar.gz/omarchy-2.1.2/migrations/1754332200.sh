echo "Remove old Omarchy TUI app now that we have the Omarchy Menu"

rm -f ~/.local/share/applications/omarchy.desktop
