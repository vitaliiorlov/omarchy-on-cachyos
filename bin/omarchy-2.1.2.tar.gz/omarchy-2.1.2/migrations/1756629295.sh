echo "Ensure qt5-wayland is installed so KeepassXC, Nextcloud, Sqlite Browser, and other apps display correctly"

omarchy-pkg-add qt5-wayland
