echo "Add LocalSend as new default application"

omarchy-pkg-add localsend
