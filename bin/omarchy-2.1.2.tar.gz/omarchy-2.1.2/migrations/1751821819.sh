echo "Install bash-completion"

omarchy-pkg-add bash-completion
