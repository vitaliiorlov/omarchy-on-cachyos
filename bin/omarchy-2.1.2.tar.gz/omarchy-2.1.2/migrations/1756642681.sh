echo "Fix audio input on AMD Framework laptops"

source $OMARCHY_PATH/install/config/hardware/fix-f13-amd-audio-input.sh || true
