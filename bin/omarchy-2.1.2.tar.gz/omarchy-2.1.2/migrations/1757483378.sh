echo "6Ghz Wi-Fi + Intel graphics acceleration for existing installations"

$OMARCHY_PATH/install/config/hardware/set-wireless-regdom.sh
$OMARCHY_PATH/install/config/hardware/intel.sh
