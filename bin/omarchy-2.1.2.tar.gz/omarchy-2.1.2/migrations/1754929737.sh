echo "Update Walker config to add 60s timeout such that it won't conflict with screensaver"

omarchy-refresh-walker
