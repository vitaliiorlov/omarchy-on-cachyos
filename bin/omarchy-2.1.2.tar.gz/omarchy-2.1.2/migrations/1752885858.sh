echo "Install slurp + wl-screenrec for new ALT+PrintScreen screen recorder"

omarchy-pkg-add slurp wl-screenrec
