echo "Install ffmpegthumbnailer for video thumbnails in the file manager"

omarchy-pkg-add ffmpegthumbnailer
