echo "Update plymouth theme to avoid freetype2 issue that broke the styled login screen"
omarchy-refresh-plymouth
