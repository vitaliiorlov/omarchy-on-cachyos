echo "Use new Omarchy mirror as default"

omarchy-refresh-pacman-mirrorlist
