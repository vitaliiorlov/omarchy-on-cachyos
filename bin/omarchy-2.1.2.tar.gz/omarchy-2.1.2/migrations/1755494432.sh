echo "Disable USB autosuspend"

$OMARCHY_PATH/install/config/hardware/usb-autosuspend.sh
