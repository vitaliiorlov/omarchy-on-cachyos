echo "Fix Plymouth login positioning in multi-monitor setups + limit password from overflowing"
omarchy-refresh-plymouth
