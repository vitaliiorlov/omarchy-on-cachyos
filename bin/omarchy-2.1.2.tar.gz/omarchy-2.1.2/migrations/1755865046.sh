echo "Switch from lazydocker-bin to lazydocker official"

omarchy-pkg-drop lazydocker-bin
omarchy-pkg-add lazydocker
