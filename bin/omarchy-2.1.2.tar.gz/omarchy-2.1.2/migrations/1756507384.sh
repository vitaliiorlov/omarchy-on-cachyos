echo "Replace JetBrains Mono font with the Nerd Font edition"

omarchy-pkg-add ttf-jetbrains-mono-nerd
omarchy-pkg-drop ttf-jetbrains-mono
