echo "Add chromium-flags.conf"

omarchy-refresh-config chromium-flags.conf
