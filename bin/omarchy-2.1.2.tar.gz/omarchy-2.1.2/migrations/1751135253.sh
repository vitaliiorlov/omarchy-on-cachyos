echo "Add missing installation of bat (used by the ff alias)"

omarchy-pkg-add bat
