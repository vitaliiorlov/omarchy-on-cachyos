echo "Fix the expand icon margin in the Waybar style"

omarchy-refresh-config waybar/style.css
