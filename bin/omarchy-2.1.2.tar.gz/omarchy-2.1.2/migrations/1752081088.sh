echo "Permanently fix F-keys on Apple-mode keyboards (like Lofree Flow84)"

source $OMARCHY_PATH/install/config/hardware/fix-fkeys.sh
