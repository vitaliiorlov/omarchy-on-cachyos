echo "Remove needless fcitx5-configtool package"

omarchy-pkg-drop fcitx5-configtool
