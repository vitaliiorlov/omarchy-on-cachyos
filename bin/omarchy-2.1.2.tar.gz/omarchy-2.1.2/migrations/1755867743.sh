echo "Copy Omarchy logo to ~/.config/omarchy/branding/screensaver.txt so screensaver can be personalized"

mkdir -p ~/.config/omarchy/branding
cp $OMARCHY_PATH/logo.txt ~/.config/omarchy/branding/screensaver.txt
