echo "Add support for accessing Android phone data via file manager"

omarchy-pkg-add gvfs-mtp
