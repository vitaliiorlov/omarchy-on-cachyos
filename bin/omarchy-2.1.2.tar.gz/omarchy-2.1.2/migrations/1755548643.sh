echo "Install wf-recorder for intel based device"

omarchy-pkg-add wf-recorder
