echo "Stop restarting waybar on unlock to see if we have solved the stacking problem for good"

omarchy-refresh-hypridle
