echo "Remove no-longer-needed sudoless package listing updates"

sudo rm -f /etc/sudoers.d/repositories
