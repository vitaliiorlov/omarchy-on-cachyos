echo "Installing missing fd terminal tool for finding files"

omarchy-pkg-add fd
