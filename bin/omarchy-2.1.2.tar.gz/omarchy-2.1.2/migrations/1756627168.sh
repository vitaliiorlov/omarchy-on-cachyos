echo "Include OS Age and Uptime icons in About"

omarchy-refresh-fastfetch
