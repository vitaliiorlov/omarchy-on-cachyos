echo "Ensure latest uwsm is installed"

sudo pacman -Syu --noconfirm uwsm
