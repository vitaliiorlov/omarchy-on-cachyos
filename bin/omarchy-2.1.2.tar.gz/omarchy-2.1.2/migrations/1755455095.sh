echo "Ensure TTE and dependencies are installed"

omarchy-pkg-add python-poetry-core python-terminaltexteffects
