echo "Add back ttf-ia-writer if it was missing"

omarchy-pkg-add ttf-ia-writer
