echo "Install satty for the new screenshot flow"

omarchy-pkg-add satty
