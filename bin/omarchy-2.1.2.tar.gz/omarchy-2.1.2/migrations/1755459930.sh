echo "Add potentially missing dependency for power profile controls"

omarchy-pkg-add python-gobject
